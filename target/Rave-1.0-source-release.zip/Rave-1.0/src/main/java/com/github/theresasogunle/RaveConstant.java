package com.github.theresasogunle;

/**
 * @author Theresa
 */
public class RaveConstant {

    public static String SECRET_KEY;
    public static String PUBLIC_KEY;
    public static Environment ENVIRONMENT;

}
    
